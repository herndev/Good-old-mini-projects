<?php
	$hostname = "localhost";
	$db_username = "root";
	$db_password = "";
	$db = "online_voting_db";
?>